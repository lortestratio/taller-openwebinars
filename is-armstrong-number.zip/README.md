Código en C utilizado en los cursos de Open Webinars:
* Curso de Jenkins: Herramientas para exprimir nuestro código
* Curso de Jenkins: Escalando Jenkins con workers en Google Cloud

# Compilar

```bash
> make
```

# Ejecutar el código

```bash
> ./is_armstrong_number
```

# Limpiar

```bash
> make clean
```

